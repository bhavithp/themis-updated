import React from 'react';
import Snackbar from '@mui/material/Snackbar';
import {Alert} from 'reactstrap';
import { styled } from '@mui/system';


const useStyles = styled((theme) => ({
  root: {
    width: '100%',
    '& > * + *': {
      marginTop: theme.spacing(2),
    },
  },
}));


export default function ProcessAlert({color, message}) {

  const classes = useStyles();
  const [open, setOpen] = React.useState(true);


  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };

  return (
    <div className={classes.root}>

      <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
        <Alert toggle={handleClose} color={color}>
          {message}
        </Alert>
      </Snackbar>

    </div>
  );
}
