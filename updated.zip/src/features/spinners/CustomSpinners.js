import React from 'react'
import { Spinner } from 'reactstrap';
import Style from './CustomSpinners.module.css';
import Backdrop from '@mui/material/Backdrop';
import { styled } from '@mui/system';

const useStyles = styled((theme) => ({
    backdrop: {
      zIndex: theme.zIndex.drawer + 1,
      color: '#fff',
    },
  }));


 

function CustomSpinners() {
    const classes = useStyles();

    return (
        <div>
            <Backdrop className={classes.backdrop} open={true}>
                <div className = {Style.customSpinner}>
                <Spinner type="grow" color="primary" className={Style.spinnerCss} />
                <Spinner type="grow" color="success" className={Style.spinnerCss} />
                <Spinner type="grow" color="danger" className={Style.spinnerCss}/>
                <Spinner type="grow" color="warning" className={Style.spinnerCss}/>
                </div>
            </Backdrop>
        </div>
      
    )
}

export default CustomSpinners
